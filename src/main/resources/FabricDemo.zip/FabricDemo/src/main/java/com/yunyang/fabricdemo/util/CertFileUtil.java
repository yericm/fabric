package com.yunyang.fabricdemo.util;

import org.bouncycastle.asn1.pkcs.PrivateKeyInfo;
import org.bouncycastle.openssl.PEMParser;
import org.bouncycastle.openssl.jcajce.JcaPEMKeyConverter;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.security.PrivateKey;

/**
 * 证书文件读取
 * @author allen
 */
public class CertFileUtil {

    /**
     * 获取private key
     * @param content
     * @return
     * @throws IOException
     */
    public static PrivateKey getPrivateKeyFromBytes(byte[] content) throws IOException {
        final Reader pemReader = new StringReader(new String(content));
        final PrivateKeyInfo pemPair;

        PEMParser pemParser = new PEMParser(pemReader);
        pemPair = (PrivateKeyInfo) pemParser.readObject();
        return new JcaPEMKeyConverter().getPrivateKey(pemPair);
    }

}
