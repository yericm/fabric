package com.yunyang.fabricdemo.entity;

import org.hyperledger.fabric.sdk.Enrollment;

import java.io.Serializable;
import java.security.PrivateKey;

/**
 * @author allen
 */
public class EnrollmentImpl implements Enrollment, Serializable {

    private static final long serialVersionUID = -2784835212445309006L;
    private final PrivateKey privateKey;
    private final String certificate;

    public EnrollmentImpl(final PrivateKey privateKey, final String certificate) {
        this.privateKey = privateKey;
        this.certificate = certificate;
    }

    @Override
    public PrivateKey getKey() {
        return this.privateKey;
    }

    @Override
    public String getCert() {
        return this.certificate;
    }

}
