package com.yunyang.fabricdemo.service.impl;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.yunyang.fabricdemo.service.IApiDataService;
import com.yunyang.fabricdemo.service.IChannelService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

/**
 * @author allen
 */
@Service
public class ApiDataServiceImpl implements IApiDataService {

    @Resource
    private IChannelService channelService;

    @Override
    public String putData(String token, DataPutRequest request) {
        JSONObject value = new JSONObject();
        value.put("req", request.getReq());
        value.put("resp", request.getResp());
        return channelService.invokeWithToken(token, "setVal", request.getApiCode(), value.toJSONString());
    }

    @Override
    public JSONObject getData(String token, String apiCode) {
        JSONObject data = channelService.queryWithToken(token, "getVal", apiCode);
        JSONObject root = new JSONObject();
        root.put("apiCode", apiCode);
        root.put("value", data.get("data"));
        return root;
    }

    @Override
    public JSONArray getHistory(String token, String apiCode) {
        JSONObject data = channelService.queryWithToken(token, "getHistory", apiCode);
        return data.getJSONArray("data");
    }

    @Override
    public JSONObject getTransactionDetail(String token, String txId) {
        return channelService.getTransactionDetail(token, txId);
    }
}
