package com.yunyang.fabricdemo.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.google.protobuf.InvalidProtocolBufferException;
import com.yunyang.fabricdemo.config.ChannelListConfig;
import com.yunyang.fabricdemo.config.OrgConfig;
import com.yunyang.fabricdemo.config.OrgListConfig;
import com.yunyang.fabricdemo.config.UserConfig;
import com.yunyang.fabricdemo.dto.EBizCode;
import com.yunyang.fabricdemo.exception.YYException;
import com.yunyang.fabricdemo.service.IChannelService;
import com.yunyang.fabricdemo.util.FabricUserUtil;
import lombok.Builder;
import lombok.Data;
import lombok.ToString;
import lombok.extern.slf4j.Slf4j;
import org.hyperledger.fabric.sdk.*;
import org.hyperledger.fabric.sdk.exception.CryptoException;
import org.hyperledger.fabric.sdk.exception.InvalidArgumentException;
import org.hyperledger.fabric.sdk.exception.ProposalException;
import org.hyperledger.fabric.sdk.exception.TransactionException;
import org.hyperledger.fabric.sdk.security.CryptoSuite;
import org.hyperledger.fabric_ca.sdk.exception.EnrollmentException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.event.ApplicationStartedEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import javax.annotation.Resource;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.security.Security;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

/**
 * @author allen
 */
@Service
@Slf4j
public class ChannelServiceImpl implements IChannelService, ApplicationListener<ApplicationStartedEvent> {

    static {
        Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
    }

    /**
     * channelName => channel mapping
     */
    private HashMap<String, Channel> channels = new HashMap<>();
    /**
     * channelName => client mapping
     */
    private HashMap<String, HFClient> clients = new HashMap<>();

    @Value("${com.yunyang.useCa}")
    private Boolean useCa;

    @Value("${com.yunyang.chaincodeName}")
    private String chaincodeName;

    @Resource
    private OrgListConfig orgListConfig;

    @Resource
    private ChannelListConfig channelListConfig;

    @Override
    public void onApplicationEvent(ApplicationStartedEvent applicationStartedEvent) {
        log.info("try to initialize channels");
        initChannels();
    }

    @Override
    public String invokeWithToken(String token, String func, String... args) {
        if (StringUtils.isEmpty(token) || StringUtils.isEmpty(func) ) {
            log.error("wrong token: {} or func: {}", token, func);
            throw new YYException(EBizCode.MISSING_TOKEN_OR_FUNC);
        }
        TokenBindInfo bindInfo = getByToken(token);
        String txId = null;
        try {
            txId = sendTransaction(bindInfo.getClient(), bindInfo.getChannel(), bindInfo.getChaincodeID(), bindInfo.getUser(), func, args)
                    .thenApplyAsync(BlockInfo.EnvelopeInfo::getTransactionID)
                    .exceptionally(e -> {
                        e.printStackTrace();
                        log.error("invoke failed: {}", e.getMessage());
                        throw new YYException(EBizCode.INVOKE_CHAINCODE_FAILED);
                    }).get();
        } catch (InvalidArgumentException | ProposalException | InterruptedException | ExecutionException e) {
            e.printStackTrace();
            throw new YYException(EBizCode.INVOKE_CHAINCODE_FAILED);
        }
        return txId;
    }

    @Override
    public JSONObject queryWithToken(String token, String func, String... args) {
        TokenBindInfo bindInfo = getByToken(token);
        QueryByChaincodeRequest request = bindInfo.getClient().newQueryProposalRequest();
        request.setArgs(args);
        request.setFcn(func);
        request.setChaincodeID(bindInfo.getChaincodeID());
        Collection<ProposalResponse> proposals = null;
        try {
            proposals = bindInfo.getChannel().queryByChaincode(request);
        } catch (InvalidArgumentException | ProposalException e) {
            e.printStackTrace();
            return null;
        }
        for (ProposalResponse proposal : proposals) {
            if ( !proposal.isVerified() || proposal.getStatus() != ChaincodeResponse.Status.SUCCESS ) {
                System.out.println("Failed query proposal from peer!");
                throw new YYException(EBizCode.PROPOSAL_RESP_ERR);
            } else {
                String payload = new String(proposal.getProposalResponse().getResponse().getPayload().toByteArray());
                System.out.println("Query Success: " + payload);
                return JSONObject.parseObject(payload);
            }
        }
        return null;
    }

    @Override
    public JSONObject getTransactionDetail(String token, String txId) {
        JSONObject root = new JSONObject();

        TokenBindInfo bindInfo = getByToken(token);

        // 获取区块信息
        BlockchainInfo blockchainInfo = null;
        TransactionInfo transactionInfo = null;
        BlockInfo blockInfo = null;
        try {
            blockchainInfo = bindInfo.getChannel().queryBlockchainInfo();
            transactionInfo = bindInfo.getChannel().queryTransactionByID(txId);
            blockInfo = bindInfo.getChannel().queryBlockByTransactionID(txId);
        } catch (ProposalException | InvalidArgumentException e) {
            e.printStackTrace();
            throw new YYException(EBizCode.QUERY_TRANSACTION_DETAIL_FAILED);
        }
        JSONObject blockObj = new JSONObject();
        blockObj.put("height", blockchainInfo.getHeight());
        blockObj.put("curNumber", blockInfo.getBlockNumber());
        blockObj.put("prevHash", blockInfo.getPreviousHash());
        blockObj.put("channelName", bindInfo.getChannel().getName());
        root.put("block", blockObj);

        // 获取交易数据
        JSONObject transactionObj = new JSONObject();
        JSONObject envelopObj = new JSONObject();
        envelopObj.put("payload", transactionInfo.getEnvelope().getPayload().toStringUtf8());
        envelopObj.put("sign", transactionInfo.getEnvelope().getSignature().toStringUtf8());
        transactionObj.put("envelop", envelopObj);
        transactionObj.put("txId", txId);
        try {
            transactionObj.put("timestamp", blockInfo.getEnvelopeInfo(0).getTimestamp().getTime()/1000);
        } catch (InvalidProtocolBufferException e) {
            e.printStackTrace();
            throw new YYException(EBizCode.QUERY_TRANSACTION_DETAIL_FAILED);
        }
        root.put("transaction", transactionObj);
        return root;
    }

    /**
     * 初始化通道
     */
    private void initChannels() {
        channelListConfig.getChannels().forEach(channelConfig -> {
            try {
                HFClient client = HFClient.createNewInstance();
                // 设置证书套件
                CryptoSuite cryptoSuite = CryptoSuite.Factory.getCryptoSuite();
                client.setCryptoSuite(cryptoSuite);
                // 设置用户
                User user = FabricUserUtil.getFabricUser4Local(
                        channelConfig.getAdmin().getUserName(),
                        channelConfig.getAdmin().getOrg(),
                        channelConfig.getAdmin().getOrgId(),
                        channelConfig.getAdmin().getCert(),
                        channelConfig.getAdmin().getPrivateKey());
                client.setUserContext(user);

                Channel channel = client.newChannel(channelConfig.getName());
                Orderer orderer;
                List<Peer> peers;
                if ( channelConfig.getUseTls() ) { // 使用TLS
                    // 设置orderer
                    Properties ordererProperties = new Properties();
                    ordererProperties.put("pemFile", channelConfig.getOrderer().getCa());
                    // ordererProperties.put("clientCertFile", channelConfig.getOrderer().getClientCert());
                    // ordererProperties.put("clientKeyFile", channelConfig.getOrderer().getClientKey());
                    orderer = client.newOrderer(
                            channelConfig.getOrderer().getName(),
                            channelConfig.getOrderer().getUrl(),
                            ordererProperties);

                    // 设置peers
                    peers = channelConfig.getPeers().stream().map(peerConfig -> {
                        Properties peerProperties = new Properties();
                        peerProperties.put("pemFile", peerConfig.getCa());
                        // peerProperties.put("clientCertFile", peerConfig.getClientCert());
                        // peerProperties.put("clientKeyFile", peerConfig.getClientKey());
                        try {
                            return client.newPeer(peerConfig.getName(), peerConfig.getUrl(), peerProperties);
                        } catch (InvalidArgumentException e) {
                            e.printStackTrace();
                            return null;
                        }
                    }).collect(Collectors.toList());
                } else {
                    orderer = client.newOrderer(
                            channelConfig.getOrderer().getName(),
                            channelConfig.getOrderer().getUrl());
                    peers = channelConfig.getPeers().stream().map(peerConfig -> {
                        try {
                            return client.newPeer(peerConfig.getName(), peerConfig.getUrl());
                        } catch (InvalidArgumentException e) {
                            e.printStackTrace();
                            return null;
                        }
                    }).collect(Collectors.toList());
                }
                channel.addOrderer(orderer);
                for (Peer peer : peers) {
                    if (null == peer) {
                        continue;
                    }
                    channel.addPeer(peer);
                }
                channel.initialize();
                // name => channel mapping
                channels.put(channelConfig.getName(), channel);
                clients.put(channelConfig.getName(), client);
            } catch (InvalidArgumentException | TransactionException | InstantiationException | InvocationTargetException | NoSuchMethodException | IllegalAccessException | CryptoException | ClassNotFoundException | IOException e) {
                e.printStackTrace();
            }
        });
        log.info("current channels: {}, clients: {}", channels.size(), clients.size());
    }

    /**
     * 异步调用
     * @param client
     * @param channel
     * @param chaincodeID
     * @param user
     * @return
     */
    private CompletableFuture<BlockEvent.TransactionEvent> sendTransaction(
            final HFClient client,
            final Channel channel,
            final ChaincodeID chaincodeID,
            final User user,
            final String func,
            final String... args) throws InvalidArgumentException, ProposalException {
        TransactionProposalRequest request = client.newTransactionProposalRequest();
        request.setChaincodeID(chaincodeID);
        request.setFcn(func);
        request.setArgs(args);
        request.setProposalWaitTime(300 * 1000);
        request.setUserContext(user);
        Collection<ProposalResponse> proposalResponses = channel.sendTransactionProposal(request);
        for (ProposalResponse response : proposalResponses) {
            if ( response.getStatus() == ChaincodeResponse.Status.SUCCESS ) {
                log.info("Successful transaction proposal response TxId: {} from peer {}. args: {}",
                        response.getTransactionID(),
                        response.getPeer(),
                        args);
                // TODO: 落库存储
            } else {
                log.error("failed transaction proposal: {}", response.getMessage());
                throw new YYException(EBizCode.INVOKE_CHAINCODE_FAILED);
            }
        }
        return channel.sendTransaction(proposalResponses, user);
    }

    @Data
    @ToString
    @Builder
    private static class TokenBindInfo {
        private HFClient client;
        private Channel channel;
        private ChaincodeID chaincodeID;
        private User user;
    }

    private TokenBindInfo getByToken(final String token) {
        OrgConfig orgConfig = orgListConfig.findOrgByName(token);
        if (null == orgConfig) {
            log.error("can not find org config matched token:{}", token);
            throw new YYException(EBizCode.GET_CONFIG_ORG_FAILED);
        }
        if ( null == orgConfig.getChannels() || orgConfig.getChannels().isEmpty() ) {
            log.error("org does not joined any channels. name: {}", token);
            throw new YYException(EBizCode.GET_CONFIG_ORG_CHANNELS_FAILED);
        }
        // TODO: 一个组织加入到多个channel，如何处理？
        HFClient client = clients.get(orgConfig.getChannels().get(0));
        Channel channel = channels.get(orgConfig.getChannels().get(0));
        if ( null == client || null == channel ) {
            log.error("no client or channel matched with channelName: {}", orgConfig.getChannels().get(0));
            throw new YYException(EBizCode.GET_CHANNEL_MAP_CLIENT_FAILED);
        }
        UserConfig adminConfig = orgConfig.getAdmin();
        if ( null == adminConfig ) {
            log.error("no admin user config under orgName: {}", orgConfig.getName());
            throw new YYException(EBizCode.GET_ORG_ADMIN_FAILED);
        }
        User user = null;
        try {
            if ( useCa ) {
                user = FabricUserUtil.getFabricUser4Ca(
                        "admin",
                        "adminpw",
                        orgConfig.getName(),
                        orgConfig.getId());
            } else {
                user = FabricUserUtil.getFabricUser4Local(
                        adminConfig.getUserName(),
                        orgConfig.getName(),
                        orgConfig.getId(),
                        adminConfig.getCert(),
                        adminConfig.getPrivateKey());
            }
        } catch (IOException | EnrollmentException | org.hyperledger.fabric_ca.sdk.exception.InvalidArgumentException e) {
            e.printStackTrace();
            throw new YYException(EBizCode.GET_FABRIC_USER_LOCAL_FAIELD);
        }
        ChaincodeID chaincodeID = ChaincodeID.newBuilder().setName(chaincodeName).build();
        return TokenBindInfo.builder()
                .client(client)
                .channel(channel)
                .chaincodeID(chaincodeID)
                .user(user)
                .build();
    }


}
