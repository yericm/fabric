package com.yunyang.fabricdemo.dto;

import lombok.Data;

/**
 * @author allen
 */
@Data
public class Result<T> {

    private int code;

    private String err;

    private T data;

    private Result(int code, String err, T data) {
        this.code = code;
        this.err = err;
        this.data = data;
    }

    /**
     * 构造成功数据
     * @param data 数据
     * @return 结果
     */
    public static <T> Result<T> success(T data) {
        return new Result<>(200, null, data);
    }

    /**
     * 构造失败数据
     * @param eBizCode 错误码
     * @return 结果
     */
    public static <T> Result<T> fail(EBizCode eBizCode) {
        return new Result<>(eBizCode.value(), eBizCode.errmsg(), null);
    }

    /**
     * 构造失败数据
     * @param code 错误码
     * @param errMsg 错误信息
     * @return 结果
     */
    public static <T> Result<T> fail(int code, String errMsg) {
        return new Result<>(code, errMsg, null);
    }
}
