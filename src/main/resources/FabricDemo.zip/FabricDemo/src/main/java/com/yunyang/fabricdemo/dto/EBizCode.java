package com.yunyang.fabricdemo.dto;

/**
 * 业务错误码定义
 *
 * @author allen
 */
public enum EBizCode {

    //参数错误从1开头
    PARAMETER_ERROR(1000, "参数错误"),

    MISSING_TOKEN_OR_FUNC(2000, "缺少token或func参数"),
    INVOKE_CHAINCODE_FAILED(2001, "调用chaincode失败"),
    PROPOSAL_RESP_ERR(2002, "proposal失败"),
    QUERY_TRANSACTION_DETAIL_FAILED(2003, "获取交易详细信息失败"),

    GET_CONFIG_ORG_FAILED(3001, "获取组织配置信息失败"),
    GET_CONFIG_ORG_CHANNELS_FAILED(3002, "获取组织配置channel信息失败"),
    GET_CHANNEL_MAP_CLIENT_FAILED(3003, "获取通道名称映射对象失败"),
    GET_ORG_ADMIN_FAILED(3004, "获取组织管理员信息失败"),

    GET_CA_CLIENT_FAILED(4000, "初始化ca client失败"),
    GET_FABRIC_USER_LOCAL_FAIELD(4001, "获取Local User失败"),



    /**
     * 系统错误
     */
    NOT_IMPLEMENTED(9998, "功能未开放"),
    SYSTEM_ERROR(9999, "服务器开小差");

    private int value;
    private String errmsg;

    EBizCode(final int value, final String errmsg) {
        this.value = value;
        this.errmsg = errmsg;
    }

    public int value() {
        return this.value;
    }

    public String errmsg() {
        return this.errmsg;
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
