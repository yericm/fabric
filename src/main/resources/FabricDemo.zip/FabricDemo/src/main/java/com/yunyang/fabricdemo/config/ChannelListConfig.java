package com.yunyang.fabricdemo.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * @author allen
 */
@Component
@ConfigurationProperties(prefix = "com.yunyang")
@Data
public class ChannelListConfig {

    private List<ChannelConfig> channels = new ArrayList<>();

}
