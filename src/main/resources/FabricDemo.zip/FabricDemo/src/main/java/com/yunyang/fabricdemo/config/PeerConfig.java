package com.yunyang.fabricdemo.config;

import lombok.Data;

/**
 * @author allen
 */
@Data
public class PeerConfig {

    private String name;

    private String url;

    private String ca;

    private String cert;

    private String clientCert;

    private String clientKey;

}
