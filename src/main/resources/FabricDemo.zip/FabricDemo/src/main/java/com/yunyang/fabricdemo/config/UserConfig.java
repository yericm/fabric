package com.yunyang.fabricdemo.config;

import lombok.Data;

/**
 * @author allen
 */
@Data
public class UserConfig {

    private String userName;

    private String cert;

    private String privateKey;

    private Boolean isAdmin;

}
