package com.yunyang.fabricdemo.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * @author allen
 */
@ConfigurationProperties(prefix = "com.yunyang.channels.orderer")
@Data
public class OrdererConfig {

    private String name;

    private String ca;

    private String cert;

    private String clientCert;

    private String clientKey;

    private String url;

}
