package com.yunyang.fabricdemo.config;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @author allen
 */
@Data
public class ChannelConfig {

    private String name;

    private AdminConfig admin;

    private Boolean useTls;

    private OrdererConfig orderer;

    private List<PeerConfig> peers = new ArrayList<>();


}
