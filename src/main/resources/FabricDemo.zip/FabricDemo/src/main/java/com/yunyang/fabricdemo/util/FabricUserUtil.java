package com.yunyang.fabricdemo.util;

import com.yunyang.fabricdemo.entity.EnrollmentImpl;
import com.yunyang.fabricdemo.entity.FabricUserImpl;
import org.apache.commons.compress.utils.IOUtils;
import org.hyperledger.fabric.sdk.Enrollment;
import org.hyperledger.fabric.sdk.User;
import org.hyperledger.fabric_ca.sdk.HFCAClient;
import org.hyperledger.fabric_ca.sdk.exception.EnrollmentException;
import org.hyperledger.fabric_ca.sdk.exception.InvalidArgumentException;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.security.PrivateKey;

import static com.yunyang.fabricdemo.util.CertFileUtil.getPrivateKeyFromBytes;

/**
 * @author allen
 */
public class FabricUserUtil {

    /**
     * 获取本地用户信息
     * @param userName
     * @param org
     * @param orgId
     * @return
     */
    public static User getFabricUser4Local(final String userName,
                                           final String org,
                                           final String orgId,
                                           final String certFileName,
                                           final String privateKeyFileName) throws IOException {
        FabricUserImpl user = new FabricUserImpl(userName, org);
        user.setMspId(orgId);
        String certificate = new String(IOUtils.toByteArray(
                new FileInputStream(new File(certFileName))
        ), "UTF-8");
        PrivateKey privateKey = getPrivateKeyFromBytes(IOUtils.toByteArray(
                new FileInputStream(new File(privateKeyFileName))
        ));
        EnrollmentImpl enrollment = new EnrollmentImpl(privateKey, certificate);
        user.setEnrollment(enrollment);
        return user;
    }

    /**
     * 从CA服务中获取用户信息
     * @param userName
     * @param password
     * @param org
     * @param orgId
     * @return
     */
    public static User getFabricUser4Ca(final String userName, final String password, final String org, final String orgId) throws IOException, InvalidArgumentException, EnrollmentException {
        FabricUserImpl user = new FabricUserImpl(userName, org);
        user.setMspId(orgId);
        HFCAClient hfcaClient = HFCAClient.createNewInstance("http://", null);
        Enrollment enrollment = hfcaClient.enroll(userName, password);
        user.setEnrollment(enrollment);
        return user;
    }


}
