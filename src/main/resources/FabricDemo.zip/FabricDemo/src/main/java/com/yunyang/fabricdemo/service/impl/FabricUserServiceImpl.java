package com.yunyang.fabricdemo.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.yunyang.fabricdemo.dto.EBizCode;
import com.yunyang.fabricdemo.entity.FabricUserImpl;
import com.yunyang.fabricdemo.exception.YYException;
import com.yunyang.fabricdemo.service.IFabricUserService;
import lombok.extern.slf4j.Slf4j;
import org.hyperledger.fabric.sdk.Enrollment;
import org.hyperledger.fabric.sdk.exception.CryptoException;
import org.hyperledger.fabric.sdk.exception.InvalidArgumentException;
import org.hyperledger.fabric.sdk.security.CryptoSuite;
import org.hyperledger.fabric_ca.sdk.HFCAClient;
import org.hyperledger.fabric_ca.sdk.RegistrationRequest;
import org.hyperledger.fabric_ca.sdk.exception.EnrollmentException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.lang.reflect.InvocationTargetException;
import java.net.MalformedURLException;

/**
 * @author allen
 */
@Service
@Slf4j
public class FabricUserServiceImpl implements IFabricUserService {

    private HFCAClient hfcaClient;

    @Value("${com.yunyang.caUrl}")
    private String caUrl;

    @Override
    public JSONObject register() {
        FabricUserImpl user = new FabricUserImpl("user01", "org1");
        String resp = "";
        try {
            RegistrationRequest request = new RegistrationRequest("");
            request.setType("peer");
            resp = getClient().register(request, user);
            log.info("register resp: {}", resp);
        } catch (Exception e) {
            e.printStackTrace();
            throw new YYException(EBizCode.SYSTEM_ERROR);
        }
        return null;
    }

    @Override
    public JSONObject enroll() {
        try {
            Enrollment enrollment = getClient().enroll("user001", "user001pw");
        } catch (EnrollmentException | org.hyperledger.fabric_ca.sdk.exception.InvalidArgumentException e) {
            e.printStackTrace();
            throw new YYException(EBizCode.SYSTEM_ERROR);
        }
        return null;
    }

    @Override
    public JSONObject revoke() {
        return null;
    }


    private HFCAClient getClient() {
        if ( null != hfcaClient ) {
            return hfcaClient;
        }
        try {
            hfcaClient = HFCAClient.createNewInstance(caUrl, null);
            hfcaClient.setCryptoSuite(CryptoSuite.Factory.getCryptoSuite());
        } catch (MalformedURLException | IllegalAccessException | InstantiationException | CryptoException | InvocationTargetException | InvalidArgumentException | ClassNotFoundException | NoSuchMethodException e) {
            e.printStackTrace();
            throw new YYException(EBizCode.GET_CA_CLIENT_FAILED);
        }
        return hfcaClient;
    }

}
