package com.yunyang.fabricdemo.exception;

import com.yunyang.fabricdemo.dto.EBizCode;
import lombok.Data;

/**
 * @author allen
 */
@Data
public class YYException extends RuntimeException{

    private int errorCode;

    private String errorMsg;
    public YYException(){
        super();
    }

    public YYException(final Throwable t){
        super(t);
    }

    public YYException(final  int errorCode, final  String message){
        super(message);
        this.errorCode = errorCode;
    }

    public YYException(final  int errorCode, final String message, final String errorMsg){
        super(message);
        this.errorCode = errorCode;
        this.errorMsg = errorMsg;
    }

    public YYException(final String message){
        super(message);
    }

    public YYException(final  int errorCode, final String errorMsg, final  Throwable t){
        super(errorMsg,t);
        this.errorCode = errorCode;
        this.errorMsg = errorMsg;
    }

    public YYException(final EBizCode bizCode) {
        super(bizCode.errmsg());
        this.errorCode = bizCode.value();
        this.errorMsg = bizCode.errmsg();
    }


}
