package com.yunyang.fabricdemo.controller;

import com.yunyang.fabricdemo.dto.EBizCode;
import com.yunyang.fabricdemo.dto.Result;
import com.yunyang.fabricdemo.exception.YYException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import javax.servlet.http.HttpServletRequest;

/**
 * @author allen
 */
@RestControllerAdvice
@Slf4j
public class ExceptionController {

    /**
     * 未找到路径
     * @param e
     * @return
     */
    @ResponseStatus(HttpStatus.NOT_FOUND)
    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public Result handle404(HttpRequestMethodNotSupportedException e) {
        log.error("exception: ", e);
        return Result.fail(HttpStatus.NOT_FOUND.value(), "不支持该方法");
    }

    /**
     * 抛出的业务异常
     */
    @ResponseStatus(HttpStatus.OK)
    @ExceptionHandler(YYException.class)
    public Result psdException(YYException e) {
        log.error("biz exception: ", e) ;
        return Result.fail(e.getErrorCode(), e.getErrorMsg());
    }

    /**
     * 抛出其他异常，在此处全局拦截
     * @param request
     * @param ex
     * @return
     */
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    @ExceptionHandler(Exception.class)
    public Result globalException(HttpServletRequest request, Throwable ex) {
        log.error("exception:", ex);
        return Result.fail(EBizCode.SYSTEM_ERROR);
    }


}
