package com.yunyang.fabricdemo.service;

import com.alibaba.fastjson.JSONObject;

/**
 * 通道服务
 * @author allen
 */
public interface IChannelService {

    /**
     * 根据token获取对应的channel, client, 以及admin
     * 然后发起调用
     * @param token
     * @param func
     * @param args
     * @return String
     */
    String invokeWithToken(final String token, final String func, final String... args);

    /**
     * 根据token获取对应的channel, client, 以及admin
     * 然后发起查询
     * @param token
     * @param func
     * @param args
     * @return
     */
    JSONObject queryWithToken(final String token, final String func, final String... args);

    /**
     * 根据token获取对应的channel, client, 以及admin
     * 然后获取交易详细信息
     * @param token
     * @param txId
     * @return
     */
    JSONObject getTransactionDetail(final String token, final String txId);

}
