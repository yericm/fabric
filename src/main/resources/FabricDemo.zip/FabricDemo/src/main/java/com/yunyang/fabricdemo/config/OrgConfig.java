package com.yunyang.fabricdemo.config;

import lombok.Data;

import java.util.ArrayList;
import java.util.List;

/**
 * @author allen
 */
@Data
public class OrgConfig {

    private String id;

    private String name;

    private List<UserConfig> users = new ArrayList<>();

    private List<String> channels;

    /**
     * 获取admin用户
     * @return
     */
    public UserConfig getAdmin() {
        if ( null == users || users.isEmpty() ) {
            return null;
        }
        for (UserConfig userConfig: users) {
            if ( userConfig.getIsAdmin() ) {
                return userConfig;
            }
        }
        return null;
    }


}
