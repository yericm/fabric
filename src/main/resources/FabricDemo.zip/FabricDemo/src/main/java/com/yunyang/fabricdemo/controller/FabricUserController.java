package com.yunyang.fabricdemo.controller;

import com.yunyang.fabricdemo.dto.Result;
import com.yunyang.fabricdemo.service.IFabricUserService;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

/**
 * @author allen
 */
@RestController
@RequestMapping(path = "/api/user")
public class FabricUserController {

    @Resource
    private IFabricUserService userService;

    @PostMapping(path = "/register")
    public Result register() {
        userService.register();
        return Result.success(null);
    }

}
