package com.yunyang.fabricdemo.controller;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.yunyang.fabricdemo.dto.Result;
import com.yunyang.fabricdemo.service.IApiDataService;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * @author allen
 */
@RestController
@RequestMapping(path = "/api/data")
public class ApiDataController {

    @Resource
    private IApiDataService apiDataService;

    /**
     * @api {post} /api/data/putData 写入数据
     * @apiPermission null
     * @apiGroup Data
     * @apiVersion 1.0.0
     *
     * @apiHeader {String} token 标识所在的组织
     *
     * @apiParam {String} apiCode
     * @apiParam {String} req
     * @apiParam {String} resp
     *
     * @apiSuccess {Number} code 状态码. 200为正常。
     * @apiSuccess {String} err 错误信息
     * @apiSuccess {Object} data
     */
    @PostMapping(path = "/putData")
    public Result putData(final @RequestHeader("token") String token,
                          final @RequestBody IApiDataService.DataPutRequest request) {
        JSONObject root = new JSONObject();
        root.put("txId", apiDataService.putData(token, request));
        return Result.success(root);
    }

    /**
     * @api {get} /api/data/getData 获取数据
     * @apiPermission null
     * @apiGroup Data
     * @apiVersion 1.0.0
     *
     * @apiHeader {String} token 标识所在的组织
     *
     * @apiParam {String} apiCode
     *
     * @apiSuccess {Number} code 状态码. 200为正常。
     * @apiSuccess {String} err 错误信息
     * @apiSuccess {Object} data
     * @apiSuccess {Object} data.apiCode 指标名称
     * @apiSuccess {String} data.value 数据
     */
    @GetMapping(path = "/getData")
    public Result getData(final @RequestHeader("token") String token,
                          final @RequestParam("apiCode") String apiCode) {
        return Result.success(apiDataService.getData(token, apiCode));
    }

    /**
     * @api {get} /api/data/getHistory 获取历史交易记录
     * @apiPermission null
     * @apiGroup Data
     * @apiVersion 1.0.0
     *
     * @apiHeader {String} token 标识所在的组织
     *
     * @apiParam {String} apiCode
     *
     * @apiSuccess {Number} code 状态码. 200为正常。
     * @apiSuccess {String} err 错误信息
     * @apiSuccess {Object[]} data
     * @apiSuccess {String} data.apiCode 交易主体
     * @apiSuccess {String} data.txId 交易编号
     * @apiSuccess {Long} data.timestamp 时间戳(秒级)
     * @apiSuccess {String} data.value 数据
     * @apiSuccess {Boolean} data.isDeleted 是否已删除
     */
    @GetMapping(path = "/getHistory")
    public Result getHistory(final @RequestHeader("token") String token,
                             final @RequestParam("apiCode") String apiCode) {
        JSONArray histories = apiDataService.getHistory(token, apiCode);
        return Result.success(histories);
    }

    /**
     * @api {get} /api/data/getTransactionDetail 获取交易详情
     * @apiPermission null
     * @apiGroup Data
     * @apiVersion 1.0.0
     *
     * @apiHeader {String} token 标识所在的组织
     *
     * @apiParam {String} apiCode
     *
     * @apiSuccess {Number} code 状态码. 200为正常。
     * @apiSuccess {String} err 错误信息
     * @apiSuccess {Object} data
     * @apiSuccess {Object} data.block 区块信息
     * @apiSuccess {String} data.block.prevHash 前块hash值
     * @apiSuccess {String} data.block.channelName 通道名称
     * @apiSuccess {Integer} data.block.curNumber 当前区块号
     * @apiSuccess {Integer} data.block.height 区块总高度
     * @apiSuccess {Object} data.transaction 交易信息
     * @apiSuccess {String} data.transaction.txId 交易编号
     * @apiSuccess {Long} data.transaction.timestamp 交易时间戳
     * @apiSuccess {Object} data.transaction.envelop 交易数据
     * @apiSuccess {String} data.transaction.envelop.payload 数据
     * @apiSuccess {String} data.transaction.envelop.sign 签名
     */
    @GetMapping(path = "/getTransactionDetail")
    public Result getTransactionDetail(final @RequestHeader("token") String token,
                                       final @RequestParam("txId") String txId) {
        JSONObject detail = apiDataService.getTransactionDetail(token, txId);
        return Result.success(detail);
    }


}
