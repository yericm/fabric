package com.yunyang.fabricdemo.config;

import lombok.Data;

/**
 * @author allen
 */
@Data
public class AdminConfig extends UserConfig {

    private String org;

    private String orgId;

}
