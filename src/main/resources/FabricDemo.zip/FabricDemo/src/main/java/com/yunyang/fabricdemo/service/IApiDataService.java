package com.yunyang.fabricdemo.service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import lombok.Data;

/**
 * API 数据服务
 * @author allen
 */
public interface IApiDataService {

    @Data
    class DataPutRequest {
        private String apiCode;
        private String req;
        private String resp;
    }

    /**
     * 存储data
     * @param token
     * @param request
     * @return txId 交易编号
     */
    String putData(final String token, final DataPutRequest request);

    /**
     * 获取data
     * TODO: 此处要考虑跨通道的问题
     * @param token
     * @param apiCode
     * @return
     */
    JSONObject getData(final String token, final String apiCode);


    /**
     * 获取apiCode的历史交易数据
     * @param token
     * @param apiCode
     * @return
     */
    JSONArray getHistory(final String token, final String apiCode);


    /**
     * 根据交易编号获取交易详细信息
     * @param token
     * @param txId
     * @return
     */
    JSONObject getTransactionDetail(final String token, final String txId);


}
