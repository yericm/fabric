package com.yunyang.fabricdemo.service;

import com.alibaba.fastjson.JSONObject;

/**
 * @author allen
 */
public interface IFabricUserService {

    /**
     * 向CA注册用户
     * @return
     */
    JSONObject register();

    /**
     * 向CA登记用户
     * @return
     */
    JSONObject enroll();

    /**
     * 撤销账号
     * @return
     */
    JSONObject revoke();

}
